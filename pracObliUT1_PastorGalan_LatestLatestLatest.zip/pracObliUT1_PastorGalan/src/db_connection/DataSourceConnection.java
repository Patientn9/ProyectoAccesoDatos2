package db_connection;

import java.sql.Connection;
import java.sql.SQLException;
import com.mysql.cj.jdbc.MysqlDataSource;

import encrypt.SymetricEncryptor;


public class DataSourceConnection {

	static DataSourceConnection itr;
	MysqlDataSource ds;
	
	public static DataSourceConnection getInstance() {
		if (itr == null) { itr = new DataSourceConnection(); itr.connect(); }
		
		return itr;		
	}

	private void connect() {
		this.ds = new MysqlDataSource();
		String[] data = SymetricEncryptor.decrypt("db.properties", "asd");
		
		this.ds.setUser(data[0]);
		this.ds.setPassword(data[1]);
		this.ds.setUrl(data[2]);
	}
	
	public Connection getConnection() throws SQLException {
		return this.ds.getConnection();
	}
	
	
	public void close() {
		//TODO: Queda por cerrar la esta cosa loca
		
		
	}

//	public static void main(String[] args) throws SQLException {
//				
//		DataSourceConnection x = DataSourceConnection.getInstance();
//		x.connect();
//		Connection cn = x.getConnection();
//		System.out.println(cn == null);
//		
//	}
}