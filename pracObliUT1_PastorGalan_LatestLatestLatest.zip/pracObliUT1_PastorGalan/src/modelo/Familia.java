package modelo;

import java.util.ArrayList;

public class Familia {

	String nombreID, habitad, clase, alimento;
	ArrayList<Seta> setas = new ArrayList<>();

	public Familia(String nombreID, String habitad, String clase, String alimento) {
		this.nombreID 	= nombreID;
		this.habitad 	= habitad;
		this.clase 		= clase;
		this.alimento 	= alimento;
	}
	
	public Familia(String[] familiaData) {
		this.nombreID 	= familiaData[0];
		this.habitad 	= familiaData[1];
		this.clase   	= familiaData[2];
		this.alimento 	= familiaData[3];
	}
	
	//Get
	public String[] getData() { return new String[] {this.nombreID, this.habitad, this.clase, this.alimento}; }
	
	public String getNombreID() {return this.nombreID;}

	public String getHabitad() {return this.habitad;}

	public String getClase() {return this.clase;}

	public String getlimento() {return this.alimento;}

	
	//Methods
	public void addSeta(Seta setaAdd) {
		setas.add(setaAdd);
	}

	public Seta getSeta(int idx) {
		return this.setas.get(idx);
	}

	public Seta[] getSetas() {
		Seta[] result = new Seta[this.setas.size()];
		for (int i = 0; i < this.setas.size(); i++) {
			result[i] = getSeta(i);
		}
		return result;
	}

	public Seta delSeta(int idx) {
		return this.setas.remove(idx);
	}
	
	public String[] getDataNotNull() {
		
	}
	
	
	
	//Override methods
	@Override
	public String toString() {
		return String.format("Nombre: %s, Habitad: %s, Clase: %s, Alimento: %s", 
								this.nombreID, this.habitad, this.clase, this.alimento);
	}
}
