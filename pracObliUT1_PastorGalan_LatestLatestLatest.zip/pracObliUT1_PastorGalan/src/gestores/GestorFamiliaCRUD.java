package gestores;

import modelo.Familia;

public interface GestorFamiliaCRUD {

	public abstract Familia select(Familia familia);
	public abstract Familia select(String nombreID);
	
	public abstract boolean insert(Familia familia);
	
	
	public abstract void update(Familia familiaSearch, Familia familiaNew);
	
	public abstract boolean delete(Familia familia);
	public abstract boolean delete(String nombreID);

	
	
	public abstract void closeConnection();
}
