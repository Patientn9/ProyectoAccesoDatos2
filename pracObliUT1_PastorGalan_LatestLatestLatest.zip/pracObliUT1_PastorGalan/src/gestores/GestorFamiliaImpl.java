package gestores;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import db_connection.DataSourceConnection;
import modelo.Familia;

public class GestorFamiliaImpl implements GestorFamiliaCRUD{
	
	public static void main(String[] args) {
		GestorFamiliaImpl gestor = new GestorFamiliaImpl();
		
//		gestor.insert(new Familia("Hericiaceae", "templada", "Agaricomycetes", "saprofito")); Done
//		System.out.println( gestor.select("Hericiaceae" )); Done
		
		gestor.delete()
		
	}
	
	@Override
	public boolean insert(Familia familia) {
		DataSourceConnection dsCn = DataSourceConnection.getInstance();
		String sqlCode = "INSERT INTO Familia VALUES (?, ?, ?, ?)";
		
		try(
				Connection connection = dsCn.getConnection();
				PreparedStatement statement = connection.prepareStatement(sqlCode);
			){				
				String[] familiaData = familia.getData();
				
				for (int i=0; i<familiaData.length; i++) { 	statement.setString(i+1, familiaData[i]); }
	
				return statement.executeUpdate() == 0 ? false : true;			
		
		} catch(SQLException e) {e.printStackTrace();}
		
		
		
		return false;		
	}
	
	@Override
	public Familia select(String nombreID) { return this.select( new Familia(nombreID, null, null, null) ); }
	
	@Override
	public Familia select(Familia familia) {
		DataSourceConnection dsCn = DataSourceConnection.getInstance();
		String sqlCode = "SELECT * FROM Familia WHERE nombreID = ?";
		
		try (
				Connection connection = dsCn.getConnection();
				PreparedStatement statement = connection.prepareStatement(sqlCode);
			) {
			
				String[] resultData = new String[4];
				
				
				statement.setString(1, familia.getNombreID());
				
				
				
				ResultSet result = statement.executeQuery(); result.next();
				for (int i=0; i<resultData.length; i++) { 
					resultData[i] = result.getString(i+1); 
				}
				
				
				return new Familia(resultData);
			
		}catch(SQLException e) {e.printStackTrace();}		
		return null;
	}

	@Override
	public void update(Familia familiaSearch, Familia familiaNew) {
		DataSourceConnection dsCn = DataSourceConnection.getInstance();
		
		try (Connection connection = dsCn.getConnection();){
			
			String[] fieldsToUpdate = familiaSearch.getDataNotNull(); 
			PreparedStatement statement = connection.prepareStatement(null);
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	public boolean delete(String nombreID) {  return this.delete(new Familia(nombreID, null, null, null));  }
	
	@Override
	public boolean delete(Familia familia) {
		DataSourceConnection dsCn = DataSourceConnection.getInstance();
		String sqlCode = "DELETE FROM Familia WHERE nombreID = ?";
		
		try (
			Connection connection = dsCn.getConnection();
			PreparedStatement statement = connection.prepareStatement(sqlCode);
		){
			
			
			
			statement.setString(1, familia.getNombreID());
			
			return statement.executeUpdate() == 0 ? false : true;
			
			
		} catch(SQLException e) {e.printStackTrace();}
		
		return false;
	}

	
	@Override
	public void closeConnection() {
		DataSourceConnection.getInstance().close();
		
	}

	
	
}
