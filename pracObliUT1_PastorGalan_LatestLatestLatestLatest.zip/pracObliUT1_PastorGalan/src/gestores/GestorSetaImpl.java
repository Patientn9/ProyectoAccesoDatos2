package gestores;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import db_connection.DataSourceConnection;
import modelo.Seta;

public class GestorSetaImpl implements GestorSetaCRUD {

	@Override
	public Seta select(Seta seta) {		
		String sql = "SELECT * FROM Seta WHERE nomCient = ?";
		DataSourceConnection dsCn = DataSourceConnection.getInstance();
		try (Connection con = dsCn.getConnection();PreparedStatement prp = con.prepareStatement(sql);){
			
			prp.setString(1, seta.getNomCient());		
			ResultSet rs =  prp.executeQuery(); rs.next();
			
			String[] data = new String[4];		
			for (int i = 0; i < 4; i++) {
				data[i] = rs.getString(i+1);
			}
	
			return new Seta(data, rs.getBoolean(4));
		
		} catch (Exception e) {e.printStackTrace();}
		return null;
	}

	@Override
	public Seta select(String nomCient) {return this.select( new Seta(nomCient, null, null, null, null, false) );}

	@Override
	public boolean insert(Seta seta) {
		String sql = "INSERT INTO Seta VALUES (?, ?, ?, ?, ?)";
		DataSourceConnection dsCn = DataSourceConnection.getInstance();
		try (Connection con = dsCn.getConnection(); PreparedStatement prp = con.prepareStatement(sql)){
			
			String[] setaData = seta.getStrData();
			for (int i = 0; i < setaData.length; i++) {
				prp.setString(i, setaData[i]);
			}
			prp.setBoolean(setaData.length, seta.getToxicidad());
			
			prp.executeUpdate();
			
		} catch (Exception e) {e.printStackTrace();}
		
		return false;
	}

	@Override
	public void update(Seta setaSearch, Seta SetaNew) {
		String sql = "UPDATE Seta SET nomCient = ?, nomComun = ? ";
		
	}

	@Override
	public void update(String nombreCient, Seta SetaNew) {
		
		
	}
	@Override
	public boolean delete(Seta seta) {
		
		String sql =  "DELETE FROM Seta WHERE nomCient = ?";
		DataSourceConnection dtCn = DataSourceConnection.getInstance();
		try (Connection con = dtCn.getConnection(); PreparedStatement prp = con.prepareStatement(sql)) {
			
			prp.setString(1, seta.getNomCient());
			
			prp.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean delete(String nomCient) { return this.delete( new Seta(nomCient, null, null, null, null, false ) ); }

	@Override
	public void closeConnection() {
		DataSourceConnection.getInstance().close();

	}



}
