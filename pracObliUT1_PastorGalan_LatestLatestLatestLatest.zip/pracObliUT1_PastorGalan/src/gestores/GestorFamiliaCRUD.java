package gestores;

import modelo.Familia;

public interface GestorFamiliaCRUD {

	public abstract Familia select(Familia familia);
	public abstract Familia select(String nombreID);
	
	public abstract boolean insert(Familia familia);
	
	
	public abstract int update(Familia familiaSearch, Familia familiaNew);
	
	public abstract boolean delete(Familia familia);
	public abstract boolean delete(String nombreID);

	public abstract int getSetasToxicasClase(String nombreClase);
	
	public abstract void closeConnection();
}
