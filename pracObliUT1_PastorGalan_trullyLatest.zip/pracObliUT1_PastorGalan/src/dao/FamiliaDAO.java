package dao;

import modelo.Familia;

public interface FamiliaDAO {
	public boolean insertar(Familia familia);
    public boolean eliminar(Familia familia); 
    public boolean modificar(Familia familia);
    public Familia consultar(Familia familia);   
    public void close();
}
