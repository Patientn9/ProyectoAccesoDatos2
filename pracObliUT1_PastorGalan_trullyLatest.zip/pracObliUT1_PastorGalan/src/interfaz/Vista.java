package interfaz;

public class Vista {
	
	public static String generarMenu(String titulo, String[] param) {
		String result = "";
		 for (int i=0; i<param.length; i++) {
			 result += "" + i + " - " + param[i] + "\n";
		 }
		
		return result;
	}
	
	
	public static String showMenuGetInput(String titulo, String[] param, String inputText) {
		
		System.out.println(generarMenu(titulo, param));
		
		System.out.print(inputText);
		
		return ;
		
	}
	
	public static void main(String[] args) {
		Vista.showMenuGetInput("Menu de prueba",
				new String[] {
					"Param 1",
					"Param 2",
					"Param 3"
				
				
		}, "introduce: ");
	}
}
