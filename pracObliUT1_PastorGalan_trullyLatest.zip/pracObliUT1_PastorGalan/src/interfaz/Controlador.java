package interfaz;

public class Controlador {
		
	
	
}
