package gestores;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import db_connection.DataSourceConnection;
import modelo.Seta;

public class GestorSetaImpl implements GestorSetaCRUD {

	@Override
	public Seta select(Seta seta) {		
		String sql = "SELECT * FROM Seta WHERE nomCient = ?";
		DataSourceConnection dsCn = DataSourceConnection.getInstance();
		try (Connection con = dsCn.getConnection();PreparedStatement prp = con.prepareStatement(sql);){
			
			prp.setString(1, seta.getNomCient());		
			ResultSet rs =  prp.executeQuery(); rs.next();
			
			String[] data = new String[4];		
			for (int i = 0; i < 4; i++) {
				data[i] = rs.getString(i+1);
			}
	
			return new Seta(data, rs.getBoolean(4));
		
		} catch (Exception e) {e.printStackTrace();}
		return null;
	}

	@Override
	public Seta select(String nomCient) {return this.select( new Seta(nomCient, null, null, null, null, false) );}

	@Override
	public boolean insert(Seta seta) {
		String sql = "INSERT INTO Seta VALUES (?, ?, ?, ?, ?)";
		DataSourceConnection dsCn = DataSourceConnection.getInstance();
		try (Connection con = dsCn.getConnection(); PreparedStatement prp = con.prepareStatement(sql)){
			
			String[] setaData = seta.getStrData();
			for (int i = 0; i < setaData.length; i++) {
				prp.setString(i, setaData[i]);
			}
			prp.setBoolean(setaData.length, seta.getToxicidad());
			
			prp.executeUpdate();
			
		} catch (Exception e) {e.printStackTrace();}
		
		return false;
	}

	@Override
	public int update(Seta setaSearch, Seta setaNew) {
		String sql = "UPDATE Seta SET nomCient = ?, nomComun = ?,  colorCuerpo = ?, colorEspora = ?, nombreIDFamilia = ?, toxicidad = ? WHERE nomCient = ?"; //No se como hacer para elegir otro que no sea "nomCient"
		DataSourceConnection dtSc = DataSourceConnection.getInstance();
		try (Connection con = dtSc.getConnection(); PreparedStatement prp = con.prepareStatement(sql) ) {
			
			String[] setaNewData = setaNew.getStrData();
			for (int i = 0; i < 5; i++) {
				prp.setString(i+1, setaNewData[i]);
			}
			prp.setBoolean(5, setaNew.getToxicidad());
			prp.setString(6, setaSearch.getNomCient());
			
			return prp.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int update(String nomCient, Seta setaNew) { return this.update(new Seta(nomCient, null, null, null, null, false), setaNew);}
	
	@Override
	public boolean delete(Seta seta) {
		
		String sql =  "DELETE FROM Seta WHERE nomCient = ?";
		DataSourceConnection dtCn = DataSourceConnection.getInstance();
		try (Connection con = dtCn.getConnection(); PreparedStatement prp = con.prepareStatement(sql)) {
			
			prp.setString(1, seta.getNomCient());
			
			prp.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean delete(String nomCient) { return this.delete( new Seta(nomCient, null, null, null, null, false ) ); }

	@Override
	public void closeConnection() {
		DataSourceConnection.getInstance().close();

	}

	public Seta createSeta() {
		Scanner sc = new Scanner(System.in);
		String[] inputInsert = new String[5];
		System.out.print("Nombre científico: "); inputInsert[0]= sc.nextLine();
		System.out.println("Nombre común: "); inputInsert[1]= sc.nextLine();
		System.out.println("Color del cuerpo: "); inputInsert[2]= sc.nextLine();
		System.out.println("Color de las esporas: "); inputInsert[3]= sc.nextLine();
		System.out.println("Nombre de la familia: "); inputInsert[4]= sc.nextLine();
		System.out.println("Toxicidad (true/false)"); boolean inputTox = sc.nextBoolean();
		return new Seta(inputInsert, inputTox);
	}


}
