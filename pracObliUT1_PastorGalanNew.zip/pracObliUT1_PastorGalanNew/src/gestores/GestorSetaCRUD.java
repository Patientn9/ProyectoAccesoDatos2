package gestores;

import modelo.Seta;

public interface GestorSetaCRUD {

	public abstract Seta select(Seta seta);
	public abstract Seta select(String nombreID);
	
	public abstract boolean insert(Seta seta);
	
	
	public abstract int update(Seta setaSearch, Seta SetaNew);
	public abstract int update(String nombreCient, Seta SetaNew);
	
	public abstract boolean delete(Seta seta);
	public abstract boolean delete(String nombreID);

	
	
	public abstract void closeConnection();
	
}
