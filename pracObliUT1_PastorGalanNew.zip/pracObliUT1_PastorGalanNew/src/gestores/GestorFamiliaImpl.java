package gestores;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Scanner;

import db_connection.DataSourceConnection;
import modelo.Familia;
import modelo.Seta;

public class GestorFamiliaImpl implements GestorFamiliaCRUD{
	
	public static void main(String[] args) {
//		GestorFamiliaImpl gestor = new GestorFamiliaImpl();
//		
//		gestor.insert(new Familia("Hericiaceae", "templada", "Agaricomycetes", "saprofito")); Done
//		System.out.println( gestor.select("Hericiaceae" )); Done
//		
//		gestor.update( new Familia("Mycenaceae", null, null, null), new Familia(null, "Europa", null, null));
//		
//		System.out.println( gestor.getSetasToxicasClase("Basidiomycota") );
	}
	
	
//	Main methods
	@Override
	public boolean insert(Familia familia) {
		DataSourceConnection dsCn = DataSourceConnection.getInstance();
		String sqlCode = "INSERT INTO Familia VALUES (?, ?, ?, ?)";
		
		try(Connection connection = dsCn.getConnection(); PreparedStatement statement = connection.prepareStatement(sqlCode);){				
			String[] familiaData = familia.getData();
			
			for (int i=0; i<familiaData.length; i++) { 	statement.setString(i+1, familiaData[i]);  }
			
			return statement.executeUpdate() == 0 ? false : true;			
		} catch(SQLException e) {e.printStackTrace();}		
		
		return false;		
	}
	
	
	public Familia select(String nombreID) { return this.select( new Familia(nombreID, null, null, null) ); }	
	@Override
	public Familia select(Familia familia) {
		DataSourceConnection dsCn = DataSourceConnection.getInstance();
		String sqlCode = "SELECT * FROM Familia WHERE nombreID = ?";
		
		try (Connection connection = dsCn.getConnection(); PreparedStatement statement = connection.prepareStatement(sqlCode);) {
			
				String[] resultData = new String[4];
				statement.setString(1, familia.getNombreID());
				
				
				ResultSet result = statement.executeQuery(); result.next();
				for (int i=0; i<resultData.length; i++) { 
					resultData[i] = result.getString(i+1); 
				}
				
				return new Familia(resultData);
			
		} catch(SQLException e) {e.printStackTrace();}		
		
		return null;
	}

	
	@Override
	public int update(String nombreID, Familia newFamilia) { return this.update(new Familia(nombreID, null, null, null), newFamilia);}
	@Override
	public int update(Familia familiaSearch, Familia familiaUpdate) {
		
		String[] fieldsToSearch = familiaSearch.getData(); String[] fieldsToSearchName = familiaSearch.getDataName();
		ArrayList<String[]> dataSearch = new ArrayList<>();
		for (int i=0; i<fieldsToSearch.length; i++) {
			if (fieldsToSearch[i] != null && fieldsToSearch[i] != "") {
				dataSearch.add( new String[] {fieldsToSearchName[i], fieldsToSearch[i]} );
			}
		}
		
		String[] fieldsToUpdate = familiaUpdate.getData(); String[] fieldsToUpdateName = familiaSearch.getDataName();
		ArrayList<String[]> dataUpdate = new ArrayList<>();
		for (int i=0; i<fieldsToUpdate.length; i++) {
			if (fieldsToUpdate[i] != null && fieldsToUpdate[i] != "") {
				dataUpdate.add( new String[] {fieldsToUpdateName[i], fieldsToUpdate[i]} );
			}
		}
		
		String sqlCode = "UPDATE Familia SET " + this.generateSetUpdate(dataUpdate)  + " WHERE " + this.generateSetUpdate(dataSearch) + ";";
		dataUpdate.addAll(dataSearch);
		
		
		DataSourceConnection dsCn = DataSourceConnection.getInstance();
		try (Connection connection = dsCn.getConnection(); PreparedStatement statement = connection.prepareStatement(sqlCode)){
			
			for (int i=0; i<dataUpdate.size(); i++) { statement.setString(i+1, dataUpdate.get(i)[1]); }
			
			return statement.executeUpdate();
		} catch (SQLException e) { e.printStackTrace(); }
		
		return 0;
	}	
	
	
	
	public boolean delete(String nombreID) { return this.delete(new Familia(nombreID, null, null, null));  }
	@Override
	public boolean delete(Familia familia) {
		DataSourceConnection dsCn = DataSourceConnection.getInstance();
		String sqlCode = "DELETE FROM Familia WHERE nombreID = ?";
		
		try (Connection connection = dsCn.getConnection(); PreparedStatement statement = connection.prepareStatement(sqlCode);){
			statement.setString(1, familia.getNombreID());
			
			return statement.executeUpdate() == 0 ? false : true;
			
		} catch(SQLException e) {e.printStackTrace();}
		
		return false;
	}


	@Override
	public int getSetasToxicasClase(String nombreClase) {
		DataSourceConnection dsCn = DataSourceConnection.getInstance();
		String sqlCode = "{ ? = call getPorcSetasToxicClase(?) }";
		
		try(Connection connection = dsCn.getConnection(); CallableStatement statement = connection.prepareCall(sqlCode);){				
			statement.registerOutParameter(1, Types.INTEGER);
			statement.setString(2, nombreClase);
			
			statement.executeUpdate();
			
			return statement.getInt(1);
			
			
		} catch(SQLException e) {e.printStackTrace();}		
		
		return 0;
	}
	
	
	@Override
	public void closeConnection() { DataSourceConnection.getInstance().close(); }

	
	//Additional methods
	private String generateSetUpdate(ArrayList<String[]> dataSearch) {
		String base = "DATA_NAME = ?, ";
		String result = base.repeat(dataSearch.size());
		
		
		for (String[] currData : dataSearch) {
			result = result.replaceFirst("DATA_NAME", currData[0]);
		}
		
		return result.substring(0, result.length()-2);
	}
}

