package modelo;

public class Seta {

	String nomCient, nomComun, colorCuerpo, colorEspora, nombreIDFamilia;
	boolean toxicidad;
	
	
	public Seta(String nombreCient, String nomComun, String colorCuerpo, String colorEspora, String nombreIDFamilia, boolean toxicidad ) {
		this.nomCient = nombreCient;
		this.nomComun = nomComun;
		this.colorCuerpo = colorCuerpo;
		this.colorEspora = colorEspora;
		this.nombreIDFamilia = nombreIDFamilia;
		
		this.toxicidad = toxicidad;
	}
	
	public Seta(String[] datosSeta, boolean toxicidad ) {
		this.nomCient = datosSeta[0];
		this.nomComun = datosSeta[1];
		this.colorCuerpo = datosSeta[2];
		this.colorEspora = datosSeta[3];
		this.nombreIDFamilia= datosSeta[4];
		
		this.toxicidad = toxicidad;
	}
	
	
	public String[] getStrData() {
		return new String[] {this.nomCient, this.nomComun, this.colorCuerpo, this.colorEspora, this.nombreIDFamilia};
	}
	
	
	public String[] getStrDataName() {
		return new String[] {"nomCient", "nomComun", "colorCuerpo", "colorEspora", "nombreIDFamilia"};
	}
	
	public String getNomCient() {
		return this.nomCient;
	}
	
	public boolean getToxicidad() {
		return this.toxicidad;
	}
	
}
