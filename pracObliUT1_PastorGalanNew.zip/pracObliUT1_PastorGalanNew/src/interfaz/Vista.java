package interfaz;

import java.util.Scanner;

import modelo.Familia;

public class Vista {
	
	// ┌ ┐   ─   └ ┘  │
	final public static String MENU_PRINCIPAL = ""
			+ "  Menu pricipal\n"
			+ "┌────────────────┐\n"
			+ "│ 1 - Setas      │\n"
			+ "│ 2 - Familias   │\n"
			+ "│                │\n"
			+ "│ 0 - Salir      │\n"
			+ "└────────────────┘\n"
			+ "Elige: ";
	
	final public static String MENU_FAMILIAS = ""
			+ "      Menu Familias\n"
			+ "┌─────────────────────┐\n"
			+ "│ 1 - Seleccionar     │\n"
			+ "│ 2 - Añadir          │\n"
			+ "│ 3 - Modificar       │\n"
			+ "│ 4 - Eliminar        │\n"
			+ "│                     │\n"
			+ "│ 0 - Atrás           │\n"
			+ "└─────────────────────┘\n"
			+ "Elige: ";
	
	final public static String MENU_SETAS = ""
			+ "      Menu Setas\n"
			+ "┌─────────────────────┐\n"
			+ "│ 1 - Seleccionar     │\n"
			+ "│ 2 - Añadir          │\n"
			+ "│ 3 - Modificar       │\n"
			+ "│ 4 - Eliminar        │\n"
			+ "│                     │\n"
			+ "│ 0 - Atrás           │\n"
			+ "└─────────────────────┘\n"
			+ "Elige: ";

	public static String showMenuGetInput(String menu) {
		
		System.out.print(menu);
		
		try (Scanner sc = new Scanner(System.in)) { return  sc.nextLine(); } 
		catch(Exception e) {}
		return "";
		   
	}
	
	
	public static Familia createFamilia() {
		Scanner sc = new Scanner(System.in);
		String[] inputInsert = new String[4];
		System.out.print("Nombre ID de la familia: "); inputInsert[0]= sc.nextLine();
		System.out.println("Habitat de la familia: "); inputInsert[1]= sc.nextLine();
		System.out.println("Clase de la familia: "); inputInsert[2]= sc.nextLine();
		System.out.println("Alimento que consume: "); inputInsert[4]= sc.nextLine();
		return new Familia(inputInsert);
	}

	
}
