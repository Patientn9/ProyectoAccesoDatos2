package interfaz;

import java.util.Scanner;

import gestores.GestorFamiliaImpl;
import gestores.GestorSetaImpl;
import modelo.Familia;
import modelo.Seta;


public class Controlador {
		public Controlador() {
			this.mainMenu();
		}
		
		public void mainMenu() {
			int choose = Integer.valueOf( Vista.showMenuGetInput( Vista.MENU_PRINCIPAL )  );
			
			switch (choose) {
				case 0: {System.exit(0);}
				
				case 1: { this.menuSetas();  break; }
				
				case 2: { this.menuFamilias(); break; }
				
			

			}
		}
		
		
		public void menuFamilias() {
			GestorFamiliaImpl gestorFamiliaImpl = new GestorFamiliaImpl();
			Scanner sc = new Scanner(System.in);
			Familia newFamilia;
			String input;
			int choose = Integer.valueOf(Vista.showMenuGetInput(Vista.MENU_SETAS));
			
			switch (choose) {
				case 0: {this.mainMenu(); break; } 
			
				case 1: {
					System.out.print("Elija que familia quiere ver: ");
					input = sc.nextLine();
					gestorFamiliaImpl.select(input);
					break;
				}
				
				case 2: {
					System.out.println("Escriba los parámetros de la familia a insertar: ");
					newFamilia = Vista.createFamilia();
					gestorFamiliaImpl.insert(newFamilia);
					break;
				}
				
				case 3: {
					System.out.println("Introduce los parametros a buscar de obj familia: ");
					System.out.println("Dejalo vacio si no quieres utilizar este campo!");
					Familia searchFamilia = Vista.createFamilia();
					
					
					System.out.println("Escriba los parámetros a cambiar de las familias: ");
					System.out.println("Dejalo vacio si no quieres cambiar este campo!");

					newFamilia= Vista.createFamilia();
					gestorFamiliaImpl.update(searchFamilia, newFamilia);
					
					
					break;
					}
				
				case 4: {
					System.out.print("Inserte el Id de la familia que desea eliminar: ");
					input = sc.nextLine();
					gestorFamiliaImpl.delete(input);
					break;
				}
				
			}
			
		}
	
		public void menuSetas() {
			GestorSetaImpl gestorSetaImpl = new GestorSetaImpl();
			Scanner sc = new Scanner(System.in);
			Seta newSeta;
			String input;
			int choose = Integer.valueOf(Vista.showMenuGetInput(Vista.MENU_SETAS));
			
			switch (choose) {
				case 0: {this.mainMenu(); break; } 
			
				case 1: {
					System.out.print("Elija que seta quiere ver: ");
					input = sc.nextLine();
					gestorSetaImpl.select(input);
					break;
				}
				
				case 2: {
					System.out.println("Escriba los parámetros de la seta a insertar");
					newSeta = gestorSetaImpl.createSeta();
					gestorSetaImpl.insert(newSeta);
					break;
				}
				
				case 3: {
					System.out.print("Inserte el nombre científico de la seta a editar: ");
					input = sc.nextLine();
					System.out.println("Escriba los parámetros de la seta a insertar: ");
					newSeta = gestorSetaImpl.createSeta();
					gestorSetaImpl.update(input, newSeta);
					break;
					}
				
				case 4: {
					System.out.print("Inserte el nombre científico de la seta quiere eliminar: ");
					input = sc.nextLine();
					gestorSetaImpl.delete(input);
					break;
				}
				
			}
			
		}
	
}
