package gestores;

public class GestorCRUD {

	public static void insert
}
