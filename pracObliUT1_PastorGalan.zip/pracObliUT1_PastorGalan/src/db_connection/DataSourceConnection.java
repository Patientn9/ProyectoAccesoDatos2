package db_connection;

import java.sql.Connection;
import java.sql.SQLException;
import com.mysql.cj.jdbc.MysqlDataSource;

import encrypt.SymetricEncryptor;


public class DataSourceConnection {

	static DataSourceConnection itr;
	MysqlDataSource ds;
	
	public static DataSourceConnection getInstance() {
		if (itr == null) { itr = new DataSourceConnection(); }
		
		return itr;		
	}

	public void connect() {
		this.ds = new MysqlDataSource();
		String[] data = SymetricEncryptor.decrypt("db.properties", "asd");
		
		this.ds.setUser(data[0]);
		this.ds.setPassword(data[1]);
		this.ds.setUrl(data[2]);
	}
	
	public Connection getConnection() {
		try { return this.ds.getConnection(); }
		catch (SQLException e) {e.printStackTrace();}
		
		return null;
	}
}

//DataSourceConnection x = Dadf.getInstance();
//x.connect()
//Connection cn = x.getConnection()