package encrypt;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import org.jasypt.encryption.pbe.PBEStringEncryptor;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

public class SymetricEncryptor {

	
	static public void encrypt(String filePath, String passwd) {
		try {
			PBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
			encryptor.setPassword(passwd);
			
			Properties prop = new Properties();
			prop.load( new FileInputStream(filePath) );
			
			
			prop.setProperty(
						"USER",
						encryptor.encrypt( prop.getProperty("USER") ) );	
			
			prop.setProperty(
					"PASSWD",
					encryptor.encrypt( prop.getProperty("PASSWD") ) );	
		
			
			prop.store(new FileOutputStream(filePath), "");
		} 
		catch (IOException e) {e.printStackTrace();}		
	}
	
	
	static public String[] decrypt(String filePath, String passwd) {
		try {
			String[] result = new String[3];
			
			PBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
			encryptor.setPassword(passwd);
			
			Properties prop = new Properties();
			prop.load( new FileInputStream(filePath) );			
			
			
			result[0] =  encryptor.decrypt( prop.getProperty("USER") );
			result[1] =  encryptor.decrypt( prop.getProperty("PASSWD") );
			result[2] =  prop.getProperty("URL");	
			
			
			return result;
		
		} catch (IOException e) {e.printStackTrace();}
		
		return null;
	}
	
	
	
//	public static void main(String[] args) {
//		SymetricEncryptor.encrypt("db.properties", "asd");
//		SymetricEncryptor.decrypt("db.properties", "asd");
//		
//	}
}
