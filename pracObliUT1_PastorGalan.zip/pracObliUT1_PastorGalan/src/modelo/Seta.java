package modelo;

public class Seta {

	String nombreID, nomComun, colorCuerpo, colorEspora;
	boolean toxicidad;
	
	
	public Seta(String nombreID, String nomComun, String colorCuerpo, String colorEspora, boolean toxicidad ) {
		this.nombreID = nombreID;
		this.nomComun = nomComun;
		this.colorCuerpo = colorCuerpo;
		this.colorEspora = colorEspora;
		
		this.toxicidad = toxicidad;
	}
	
	
	public String[] getStrData() {
		return new String[] {this.nombreID, this.nomComun, this.colorCuerpo, this.colorEspora};
	}
	
	public String[] getStrDataName() {
		return new String[] {"nombreID", "nomComun", "colorCuerpo", "colorEspora"};
	}
	
	
	public boolean getToxicidad() {
		return this.toxicidad;
	}
	
}
