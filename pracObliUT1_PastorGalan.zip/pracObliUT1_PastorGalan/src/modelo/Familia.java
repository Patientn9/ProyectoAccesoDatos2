package modelo;

import java.util.ArrayList;

public class Familia {

	String nombreID, habitad, clase, alimento;
	ArrayList<Seta> setas = new ArrayList<>();

	public Familia(String nombreID, String habitad, String clase, String alimento) {
		this.nombreID = nombreID;
		this.habitad = habitad;
		this.clase = clase;
		this.alimento = alimento;
	}
	
	//Get
	public String getNombreID() {
		return this.nombreID;
	}

	public String getHabitad() {
		return this.habitad;
	}

	public String getClase() {
		return this.clase;
	}

	public String getlimento() {
		return this.alimento;
	}

	
	//Methods
	public void addSeta(Seta setaAdd) {
		setas.add(setaAdd);
	}

	public Seta getSeta(int idx) {
		return this.setas.get(idx);
	}

	public Seta[] getSetas() {
		Seta[] result = new Seta[this.setas.size()];
		for (int i = 0; i < this.setas.size(); i++) {
			result[i] = getSeta(i);
		}
		return result;
	}

	public Seta delSeta(int idx) {
		return this.setas.remove(idx);
	}
}
